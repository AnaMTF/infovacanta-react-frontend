import { auth, provider } from "../config/firebase";
import { signInWithPopup } from "firebase/auth";
import { useNavigate } from "react-router-dom";

export const Login = () => {
  const navigate = useNavigate();

  const singInWithGoogle = async () => {
    const result = await signInWithPopup(auth, provider);
    console.log(result);
    navigate("/");
  }

  return (
    <div>
      <h1>Pagina de autentificare</h1>
      <button onClick={singInWithGoogle}>Autentificare cu Google</button>
    </div>
  );
}