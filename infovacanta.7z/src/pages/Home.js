export const Home = () => {
    return (
        <div>
            <h1>Pagina Principala</h1>
        </div>
    );
};